using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass1
{
    public partial class EmployeeInfo
    {
        public void Display(){
            Console.WriteLine("----------Employee details-------------");
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("ID: "+EmployeeId);
            Console.WriteLine("Mobile: "+Mobile);
            Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        }
        public void Update(){
            
        }
    }
}