using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass1
{
    
        
        public partial class EmployeeInfo{
            public enum Genders{Select,Male,Female}
            public static int s_empId=100;
            public string EmployeeId { get; }
            public string Name { get; set; }
            public string Mobile { get; set; }
            public Genders Gender { get; set; }
            public DateTime Dob { get; set; }
        }
    }