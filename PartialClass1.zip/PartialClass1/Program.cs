﻿using System;
namespace PartialClass1;
class Program{
    public static void Main(string[] args)
    {
        EmployeeInfo emp=new EmployeeInfo("gowtham",EmployeeInfo.Genders.Male,new DateTime(2001,10,01),"424342424");
        emp.Display();
    }
}
