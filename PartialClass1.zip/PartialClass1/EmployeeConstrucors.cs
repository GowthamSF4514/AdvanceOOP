using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass1
{
    
        public partial class EmployeeInfo{
            public EmployeeInfo(string Name,Genders gender,DateTime dob,string mobile){
                EmployeeId="SF"+ ++s_empId;
                Name=Name;
                Gender=gender;
                Dob=dob;
                Mobile=mobile;
            }
        }
    
}