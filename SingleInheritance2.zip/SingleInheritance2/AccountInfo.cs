using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using static SingleInheritance2.PersonalInfo;

namespace SingleInheritance2
{
    public class AccountInfo:PersonalInfo
    {
        public static int AccountNumber { get; set; }
        public static string BranchName { get; set; }
        public static string IFSCCode { get; set; }
        public double Balance { get; set; }
        public  void ShowAccountInfo(){
            Console.WriteLine("Acc Number: "+AccountNumber);
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Balance: "+Balance);
            Console.WriteLine("BranchName: "+BranchName);
            Console.WriteLine("IFSC code: "+IFSCCode);
        }
        public AccountInfo(string name,string fatherName,string mail,string phone,DateTime dob,Genders gender,int accountNumber,string branch,string ifsc,double balance):base( name, fatherName, mail, phone, dob, gender){
            AccountNumber=accountNumber;
            BranchName=branch;
            IFSCCode=ifsc;
            Balance=balance;
        }
        
        public  void Deposit(double amount){
            Balance+=amount;
        }
        public  void Withdraw(double amount){
            Balance-=amount;
        }
        public  void ShowBalance(){
            Console.WriteLine(Balance);
        }
    }
}