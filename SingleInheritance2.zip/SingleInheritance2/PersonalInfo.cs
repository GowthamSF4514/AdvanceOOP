using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SingleInheritance2
{
    public  enum Genders{Select,Male,Female}
    public class PersonalInfo
    {
         
         public static string FatherName { get; set; }
            public static string Name { get; set; }
            public static string Phone { get; set; }
            public static Genders Gender { get; set; }
            public static string Mail { get; set; }
            public static DateTime Dob { get; set; }
            public PersonalInfo(string name,string fatherName,string mail,string phone,DateTime dob,Genders gender){
                Name=name;
                FatherName=fatherName;
                Dob=dob;
                Mail=mail;
                Phone=phone;
                Gender=gender;
            }

            public PersonalInfo(){

            }
    }
}