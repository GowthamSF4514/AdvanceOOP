﻿using System;
using static SingleInheritance2.AccountInfo;
namespace SingleInheritance2;
class Program{
    public static void Main(string[] args)
    {
        AccountInfo acc1=new AccountInfo("gow","pon","gj@gmail.com","3232424",new DateTime(2001,10,01),Genders.Male,1313,"avadi","HDFC101",3242);
        AccountInfo acc2=new AccountInfo("raj","kumar","raj@gmail.com","65434",new DateTime(2001,10,01),Genders.Male,2324,"avadi","HDFC101",10000);
        acc1.ShowAccountInfo();
        acc2.ShowAccountInfo();
        acc1.ShowBalance();
        acc1.Deposit(100);
        acc1.ShowBalance();
    }
}
