using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HybridInheritance1
{
    public class MarkSheet:TheoryExamMarks,ICalculate
    {
       //Properties: MarksheetNumber, DateOfIssue, Total, Percentage
       private static int s_markSheetNo=100;
       public string MarksheetNumber { get;  } 
       public DateTime DateOfIssue { get; set; }
       public double ProjectMark { get; set; }
       private double _total=0;
       private double _percentage=0;
       public double Total { get{return _total;} set{_total=value;} }
       public Double Percentage { get{return _percentage;} set{_percentage=value;} }
       public MarkSheet(string registrationNo,string name,string fatherName,string phone,DateTime dob,Genders gender,int[] sem1,int[] sem2,int[] sem3,int[] sem4,double projectMark):base( registrationNo, name, fatherName, phone, dob, gender, sem1, sem2, sem3, sem4){
            s_markSheetNo++;
            MarksheetNumber="UG"+s_markSheetNo;
            ProjectMark=projectMark;
            DateOfIssue=DateTime.Now.Date;
       }
       public void CalculateUG(){
        for(int i=0;i<6;i++){
            Total+=Sem1[i]+Sem2[i]+Sem3[i]+Sem4[i];
        }
        Percentage=(Total/2400)*100;
       }
       public void ShowUGMarkSheet(){
        Console.WriteLine("Marksheet no: "+MarksheetNumber);
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Father's name: "+FatherName);
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Reg no: "+RegistrationNo);
        Console.WriteLine("Total mark: "+Total);
        Console.WriteLine("Percentage: "+Percentage);
        Console.WriteLine("Date of issue: "+DateOfIssue.ToString("dd/MM/yyyy"));
       }
    }
}