﻿using System; 
namespace HybridInheritance1
{
    class Program{
        public static void Main(string[] args)
        {
            PersonalInfo person=new PersonalInfo("gowtham","ponraj","42424242",new DateTime(2001,10,01),Genders.Male);
            TheoryExamMarks theory=new TheoryExamMarks(person.RegistrationNo,person.Name,person.FatherName,person.Phone,person.Dob,person.Gender,new int[]{90,90,90,90,90,90},new int[]{90,90,90,90,90,90},new int[]{90,90,90,90,90,90},new int[]{90,90,90,90,90,90});
            MarkSheet mark1=new MarkSheet(theory.RegistrationNo,theory.Name,theory.FatherName,theory.Phone,theory.Dob,theory.Gender,theory.Sem1,theory.Sem2,theory.Sem3,theory.Sem4,90);
            mark1.CalculateUG();
            mark1.ShowUGMarkSheet();
        }
    }
}