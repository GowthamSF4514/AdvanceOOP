﻿using System;
namespace SingleInheritanceStudents;
class Program{
    public static void Main(string[] args)
    {
         PersonalInfo person=new PersonalInfo("gowtham","ponraj","42424242","gowtham@gmail.com",new DateTime(2001,10,01),Genders.Male);
            StudentInfo student=new StudentInfo(person.Name,person.FatherName,person.Phone,person.Mail,person.Dob,person.Gender,25,"avadi",12,2019);
            student.ShowStudentInfo();
    }
}
