﻿// See https://aka.ms/new-console-template for more information
using System;
namespace MultiLevelInheritanceStudents;
class Program{
    public static void Main(string[] args)
    {
        PersonalInfo person=new PersonalInfo("gowtham","ponraj","42424242","gowtham@gmail.com",new DateTime(2001,10,01),Genders.Male);
        StudentInfo student=new StudentInfo(person.Name,person.FatherName,person.Phone,person.Mail,person.Dob,person.Gender,25,"avadi",12,2019);
        student.GetStudentInfo();
        Console.WriteLine("-------------------------------");
        student.ShowInfo();
         Console.WriteLine("-------------------------------");
        HSCDetails studentMark=new HSCDetails(student.Name,student.FatherName,student.Phone,student.Mail,student.Dob,student.Gender,student.RegisterNumber,student.Branch,student.Standard,student.AcademicYear,1422);
        studentMark.GetMarks(72,75,78);
        studentMark.CalculateTotalAndPercentage();
        studentMark.ShowMarkSheet();
    }
}
