using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLevelInheritanceStudents
{
    public class PersonalInfo
    {
         public string Name { get; set; }
        public string FatherName { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public DateTime Dob { get; set; }
        public Genders Gender { get; set; }
        public PersonalInfo(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender){
            Name=name;
            FatherName=fatherName;
            Phone=phone;
            Mail=mail;
            Dob=dob;
            Gender=gender;
        }
    }
}