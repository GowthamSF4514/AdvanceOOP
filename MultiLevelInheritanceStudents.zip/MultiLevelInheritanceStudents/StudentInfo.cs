using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultiLevelInheritanceStudents
{
    public enum Genders{Select,Male,Female}
    public class StudentInfo:PersonalInfo
    {
       public int RegisterNumber { get; set; }
       public string Branch { get; set; }
       public int Standard { get; set; }
       public int AcademicYear { get; set; }
       public StudentInfo(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender,int registerNumber,string branch,int standard,int academicYear):base(name,fatherName,phone,mail,dob,gender){
        RegisterNumber=registerNumber;
        Branch=branch;
        Standard=standard;
        AcademicYear=academicYear;
       }
       public void ShowInfo(){
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Father's name: "+FatherName);
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Mail: "+Mail);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Reg no: "+RegisterNumber);
        Console.WriteLine("Branch: "+Branch);
        Console.WriteLine("Standard: "+Standard);
        Console.WriteLine("Academic year: "+AcademicYear);

       }
       public void GetStudentInfo(){
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Reg no: "+RegisterNumber);
        Console.WriteLine("Branch: "+Branch);
        Console.WriteLine("Standard: "+Standard);
        Console.WriteLine("Academic year: "+AcademicYear);
       }
    }
}