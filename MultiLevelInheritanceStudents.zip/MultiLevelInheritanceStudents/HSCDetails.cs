using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;

namespace MultiLevelInheritanceStudents
{
    public class HSCDetails:StudentInfo
    {
        public int MarksheetNumber { get; set; }
        public double Physics { get; set; }
        public double Chemistry { get; set; }
        public double Maths { get; set; }
        public double Total { get; set; }
        public double Percentage { get; set; }
        public HSCDetails(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender,int registerNumber,string branch,int standard,int academicYear,int MarksheetNumber):base(name,fatherName,phone,mail,dob,gender,registerNumber,branch,standard,academicYear){
            MarksheetNumber=MarksheetNumber;

        }
        public void GetMarks(double phy,double chem,double math){
            Physics=phy;
            Chemistry=chem;
            Maths=math;
        }
        public void CalculateTotalAndPercentage(){
            Total=Physics+Chemistry+Maths;
            Percentage=((Physics+Chemistry+Maths)/300)*100;
        }
        public void ShowMarkSheet(){
            Console.WriteLine("Marksheet number: "+MarksheetNumber);
            Console.WriteLine("Student Name: "+Name);
            Console.WriteLine("Student Dob: "+Dob.ToString("dd/MM/yyyy"));
            Console.WriteLine("Physics mark: "+Physics);
            Console.WriteLine("Chemistry mark: "+Chemistry);
            Console.WriteLine("Maths mark: "+Maths);
            Console.WriteLine("Total mark: "+Total);
            Console.WriteLine("Percentage: "+Percentage);
        }
    }
}