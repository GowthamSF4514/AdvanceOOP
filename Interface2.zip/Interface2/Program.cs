﻿using System;
namespace Interface2;
class Program{
    public static void Main(string[] args)
    {
        EmployeeInfo employee=new EmployeeInfo("raj","kumar");
        StudentInfo student=new StudentInfo("gow","pon","24242424");
        employee.Display();
        student.Display();
    }
}