using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interface2
{
    public class StudentInfo:IDisplayInfo
    {
        private static int s_id=100;
        public string StudentID { get;  }
        public string Name { get; set; }
        public string FatherName { get; set; }
        public string Mobile { get; set; }
        public void Display(){
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Father Name: "+FatherName);
            Console.WriteLine("Mobile: "+Mobile);
            Console.WriteLine("Student ID: "+StudentID);
        }
        public StudentInfo(string name,string fatherName,string mobile){
            StudentID="SID"+ ++s_id;
            Name=name;
            FatherName=fatherName;
            Mobile=mobile;
        }
    }
}