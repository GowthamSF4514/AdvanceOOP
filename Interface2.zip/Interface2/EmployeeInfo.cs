using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interface2
{
    public class EmployeeInfo:IDisplayInfo
    {
        private static int s_id=100;
        public string EmployeeID { get;  }
        public string Name { get; set; }
        public string FatherName { get; set; }
       
        public void Display(){
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Father Name: "+FatherName);
            Console.WriteLine("Student ID: "+EmployeeID);
        }
        public EmployeeInfo(string name,string fatherName){
            EmployeeID="EID"+ ++s_id;
            Name=name;
            FatherName=fatherName;
        }
    }
}