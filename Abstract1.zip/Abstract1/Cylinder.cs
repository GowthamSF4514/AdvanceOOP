using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Abstract1
{
    public abstract class Cylinder : Shape
    {
        public override double Area{get;set;}
        public override double Volume{get; set;}
        void CalculateArea(){
            Area=2*3.14*Radius*(Radius+Height);
        }
        void CalculateVolume(){
            Volume=3.14*Radius*Radius*Height;
        }
    }
}