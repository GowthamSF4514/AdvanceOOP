using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Abstract1
{
    public abstract class Cubes:Shape
    {
        public override double Area{get;set;}
        public override double Volume{get; set;}
        void CalculateArea(){
            Area=6*2;
        }
        void CalculateVolume(){
            Volume=2*2*2;
        }
    }
}