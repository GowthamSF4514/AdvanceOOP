using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Virtual1
{
    public class AreaCalculator
    {
        public double Radius { get; set; }
        public virtual void Calculate(){
            Console.WriteLine("Area: "+Radius*Radius*3.14);
        }
        public AreaCalculator(double r){
            Radius=r;
        }
    }
}