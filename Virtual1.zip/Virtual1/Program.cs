﻿using System;
namespace Virtual1;
class Program{
    public static void Main(string[] args)
    {
        VolumeCalculator vol=new VolumeCalculator(3,2.1);
        AreaCalculator area=new AreaCalculator(3);
        vol.Calculate();
        area.Calculate();
    }
}
