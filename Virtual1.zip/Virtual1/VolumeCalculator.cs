using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Virtual1
{
    public class VolumeCalculator:AreaCalculator 
    {
        public double Height { get; set; }
        public override void Calculate()
        {
            Console.WriteLine("Volume: "+3.14*Radius*Radius*Height);
        }
        public VolumeCalculator(double r,double h):base(r){
            Height=h;
        }
    }
}