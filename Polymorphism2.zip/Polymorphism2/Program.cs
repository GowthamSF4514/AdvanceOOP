﻿using System;

namespace Polymorphism2;
class Program{
    public static void Main(string[] args)
    {
        Square(2);
        Square(2.35353);
        Square(2.24324234242);
        Square(222222222222222222);
    }
    static void Square(int a){
        Console.WriteLine("int - "+a*a);
    }
    static void Square(float a){
        Console.WriteLine("float - "+a*a);
    }
    static void Square(double a){
        Console.WriteLine("double - "+a*a);
    }
    static void Square(long a){
        Console.WriteLine("long - "+a*a);
    }
}
