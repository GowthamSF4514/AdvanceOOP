using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Interface1
{
    public class Duck:IAnimal
    {
        public string Name { get; set; }
        public string Habitat { get; set; }
        public string Eating { get; set; }
        public string Habit { get; set; }
        public Duck(string name,string habitat,string eating,string habit){
            Name=name;
            Habitat=habitat;
            Habit=habit;
            Eating=eating;
        }
        public void DisplayName(){
            
        }
        public void DisplayInfo(){
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Habitat: "+Habitat);
            Console.WriteLine("Habit: "+Habit);
            Console.WriteLine("Eating: "+Eating);

        }
    }
}