﻿using System;
namespace Interface1;
class Program
{
    public static void Main(string[] args)
    {
        Dog labrador = new Dog("jack", "grassland", "yes", "barks");
        Dog germanSheperd = new Dog("perucha", "grassland", "yes", "bitting");
        labrador.DisplayInfo();
        germanSheperd.DisplayInfo();
        Duck duck1 = new Duck("vathu", "swamp", "yes", "swims");
        Duck duck2 = new Duck("perry the platy", "swamp", "yes", "duck calls");
        duck1.DisplayInfo();
        duck2.DisplayInfo();
    }
}
