﻿using System;
using System.Security.Cryptography.X509Certificates;
namespace Polymorphism1;
class Program{
    public static void Main(string[] args)
    {
        Console.WriteLine("Method with one argument "+Multiply(2));
        Console.WriteLine("Method with 2 arguments with same argument type "+Multiply(2,3));
        Console.WriteLine("Method with 3 arguments with same argument type "+Multiply(2,3,4));
        Console.WriteLine("Method with 2 arguments with different argument type "+Multiply(2,2.2));
        Console.WriteLine("Method with 3 arguments with different argument type "+Multiply(2.2,3.2,5));
    }
    static int Multiply(int a){
        return a*a;
    }
    static int Multiply(int a,int b){
        return a*b;
    }
    static int Multiply(int a,int b,int c){
        return a*b*c;
    }
    static double Multiply(int a,double b){
        return a*b;
    }
    static double Multiply(double a,double b, int c){
        return a*b*c;
    }
}
