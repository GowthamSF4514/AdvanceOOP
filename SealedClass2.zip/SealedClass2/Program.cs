﻿using System;
namespace SealedClass2;
class Program{
    public static void Main(string[] args)
    {
        PatientInfo patient=new PatientInfo("gow","pon","avadi",12,"fever");
        DoctorInfo doctor=new DoctorInfo("doc1","doc1 dad");
        //gives error because it inherits sealed class
        patient.DisplayInfo();
        doctor.DisplayInfo();
    }
}