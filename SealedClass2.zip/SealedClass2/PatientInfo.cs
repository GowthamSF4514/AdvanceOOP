using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass2
{
    public sealed class PatientInfo
    {
        private static int s_patientId=100;
        public string PatientId { get; }
        public string Name { get; set; }
        public string FatherName { get; set; }
        public int BedNo { get; set; }
        public string NativePlace { get; set; }
        public string AdmittedFor { get; set; }
        public void DisplayInfo(){
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("FatherName: "+FatherName);
            Console.WriteLine("Bed No: "+BedNo);
        }
        public PatientInfo(string name,string fathername,string native,int bedno,string disease){
            s_patientId++;
            PatientId="PID"+s_patientId;
            Name=name;
            FatherName=fathername;
            NativePlace=native;
            AdmittedFor=disease;
            BedNo=bedno;
        }
    }
}