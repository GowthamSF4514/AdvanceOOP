using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Virtual2
{
    public class Rectangle:Dimension
    {
        public int Length { get; set; }
        public int Height { get; set; }
        public override void Calculate()
        {
            Area=Length*Height;
        }
        public void DisplayArea(){
            Console.WriteLine("Area: "+Area);
        }
        public Rectangle(int value1,int value2):base( value1, value2){
            Length=value1;
            Height=value2;
        }
    }
}