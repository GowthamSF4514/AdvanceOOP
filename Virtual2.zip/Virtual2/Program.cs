﻿using System;
namespace Virtual2;
class Program{
    public static void Main(string[] args)
    {
        Rectangle rect=new Rectangle(2,3);
        rect.Calculate();
        rect.DisplayArea();
        Sphere sphere=new Sphere(3);
        sphere.Calculate();
        sphere.DisplayArea();
    }
}
