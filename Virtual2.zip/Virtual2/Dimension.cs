using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Threading.Tasks;

namespace Virtual2
{
    public class Dimension
    {
        public int Value1 { get; set; }
        public int Value2 { get; set; }
        public double Area { get; set; }
        public virtual void Calculate(){
            Area=Value1*Value2;
        }
        public void DisplayArea(){
            Console.WriteLine("Area: "+Area);
        }
        public Dimension(int value1,int value2){
            Value1=value1;
            Value2=value2;
        }
        public Dimension(){
            
        }
    }
    
}