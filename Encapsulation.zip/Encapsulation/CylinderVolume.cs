using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CalculatorApp
{
    public class CylinderVolume:CircleArea
    {
        private double height;
        public double Height { get; set; }
        internal double Volume { get; set; }
        public static void CalculateVolume(){
            Volume = CalculatorCircleArea * height;
        }
    }
}