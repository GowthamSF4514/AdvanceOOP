using System;
using System.Collections.Generic;
using System.Formats.Asn1;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using MathsLib;

namespace CalculatorApp
{
    public class CircleArea:Maths
    {
        protected double radius;
        public double Radius { get; set; }
        internal double Area { get; set; }
        public static void CalculatorCircleArea(){
            Area=PI*Radius*Radius
        }
    }
}