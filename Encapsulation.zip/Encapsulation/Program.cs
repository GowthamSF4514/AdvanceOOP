﻿namespace Encapsulation;
class Program{
    public static void Main(string[] args)
    {
        //error because of access modifiers
        //cant access props
    }
}
