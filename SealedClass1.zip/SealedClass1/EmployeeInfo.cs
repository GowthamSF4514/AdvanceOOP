using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass1
{
    public sealed class EmployeeInfo
    {
        private static int s_userId=100;
        public int KeyInfo=100;
        public string UserId { get; }
        public string Password { get; set; }
        public void DisplayInfo(){
            Console.WriteLine("user id: "+UserId);
            Console.WriteLine("Password : "+Password);
        }
        public void UpdateInfo(string password){
            Password=password;
        }
    }
}