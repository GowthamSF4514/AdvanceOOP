﻿using System;
namespace SealedClass1;
class Program{
    public static void Main(string[] args)
    {
        //cant create obj , since its a sealed class
    }
}
