using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass1
{
    public class PersonalInfo
    {
        public enum Genders { Select, Male, Female }

        public string Name { get; set; }
        public string FatherName { get; set; }
        public string Mobile { get; set; }
        public Genders Gender { get; set; }
        public string Mail { get; set; }
        public void UpdateInfo(string Name,Genders gender,string fatherName,string mobile,string mail){
            Name=Name;
            FatherName=fatherName;
            Gender=gender;
            Mobile=mobile;
            Mail=mail;
        }
    }
}