using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass1
{
    public class Hack:EmployeeInfo
    {
        public string StoreUserId { get; set; }
        public string StorePassword { get; set; }
        public void ShowKeyInfo(){
            Console.WriteLine("KeyInfo: "+KeyInfo);
        }
        public void GetUserInfo(){
            StoreUserId=UserId;
            StorePassword=Password;
        }
        public void ShowUserInfo(){
            Console.WriteLine("user id: "+StoreUserId);
            Console.WriteLine("Password : "+StorePassword);
        }
    }
}