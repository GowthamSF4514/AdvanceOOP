using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultilevelInheritance2
{
    public class DepartmentDetails
    {
        public string DeptName { get; set; }
        public string Degree { get; set; }
        public DepartmentDetails(string dept,string degree){
            DeptName=dept;
            Degree=degree;
        }
    }
}