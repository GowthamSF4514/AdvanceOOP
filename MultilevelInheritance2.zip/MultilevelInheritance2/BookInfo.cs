using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultilevelInheritance2
{
    public class BookInfo : RackInfo
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string AuthorName { get; set; }
        public double Price { get; set; }
        public BookInfo(string dept, string degree, int rackNo, int colNo,int bookid,string bname,string bauthor,double price) : base(dept, degree, rackNo, colNo)
        {
            BookId=bookid;
            BookName=bname;
            AuthorName=bauthor;
            Price=price;
        }
    }
}