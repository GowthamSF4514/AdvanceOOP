﻿using System;
namespace MultilevelInheritance2;
class Program{
    public static void Main(string[] args)
    {
        BookInfo book1=new BookInfo("cse","btech",1,1,101,"harry potter","j k rowling",100);
        BookInfo book2=new BookInfo("ece","BE",1,2,102,"digital circuit","sivaram",100);
        BookInfo book3=new BookInfo("maths","btech",1,3,103,"M3","john george",100);

    }
}
