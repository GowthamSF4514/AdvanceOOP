using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultilevelInheritance2
{
    public class RackInfo : DepartmentDetails
    {
        public int RackNumber { get; set; }
        public int ColNumber { get; set; }
        public RackInfo(string dept, string degree,int rackNo,int colNo) : base(dept, degree)
        {
            RackNumber=rackNo;
            ColNumber=colNo;
        }
    }
}