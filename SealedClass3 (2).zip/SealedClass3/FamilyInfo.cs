using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass3
{
    public class FamilyInfo:PersonalInfo
    {
        public string FatherName { get; set; }
        public string MotherName { get; set; }
        public int NoOfSiblings { get; set; }
        public string Native { get; set; }
        public override void Update(){

        }
        public void DisplayInfo(){
            Console.WriteLine("FatherName: "+FatherName);
              Console.WriteLine("Mother name: "+MotherName);
                Console.WriteLine("Native: "+Native);
                  Console.WriteLine("no of siblings: "+NoOfSiblings);
        }
    }
}