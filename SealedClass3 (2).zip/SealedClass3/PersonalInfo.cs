using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass3
{
    public sealed class PersonalInfo
    {
        public enum Genders { Select, Male, Female }

        public string Name { get; set; }
        public string FatherName { get; set; }
        public string Mobile { get; set; }
        public Genders Gender { get; set; }
        public string Mail { get; set; }
        public virtual void Update(){
           
        }
        public void DisplayInfo(){
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("Father Name: "+FatherName);
            Console.WriteLine("Mobile: "+Mobile);
            Console.WriteLine("Mail: "+Mail);
            Console.WriteLine("Gender: "+Gender);
        }
    }
}