using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SealedClass3
{
    public class EmployeeInfo:FamilyInfo
    {
        public string EmployeeID { get;  }
        public DateTime Doj { get; set; }
        public override void Update(){

        }
        public override void DisplayInfo(){
            
        }
    }
}