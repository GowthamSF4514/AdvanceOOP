﻿//error because cant derive from sealed class

