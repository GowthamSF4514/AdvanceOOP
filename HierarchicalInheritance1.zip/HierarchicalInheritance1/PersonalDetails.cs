using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchicalInheritance1
{
    public enum Genders{Select,Male,Female}
    public class PersonalDetails
    {
  
        public string Name { get; set; }
        public string FatherName { get; set; }
        public string Phone { get; set; }
        public string Mail { get; set; }
        public DateTime Dob { get; set; }
        public Genders Gender { get; set; }
        public PersonalDetails(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender){
            Name=name;
            FatherName=fatherName;
            Phone=phone;
            Mail=mail;
            Dob=dob;
            Gender=gender;
        }
    }
}