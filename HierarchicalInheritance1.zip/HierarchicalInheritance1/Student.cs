using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchicalInheritance1
{
    public enum StudentDepartments{Select,CSE,IT,ECE,MECH}
    public enum Degrees{Select,BE,BTECH,ME,MTECH,MSC,PHD}
    public class Student:PersonalDetails
    {
        private static int s_studentId=100;
        public string StudentId { get; }
        public StudentDepartments Department { get; set; }
        public Degrees Degree{ get; set; }
        public int Semester { get; set; }
        public Student(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender,StudentDepartments department,Degrees degree,int semester):base( name, fatherName, phone, mail, dob, gender){
            s_studentId++;
            StudentId="SID"+s_studentId;
            Department=department;
            Degree=degree;
            Semester=semester;
        }
         public void ShowDetails(){
        Console.WriteLine("Student id: "+StudentId);
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Father's name: "+FatherName);
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Mail: "+Mail);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Department: "+Department);
        Console.WriteLine("Degree: "+Degree);
        Console.WriteLine("Semester: "+Semester);
        
        }
    }
}