using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchicalInheritance1
{
    public enum PrincipalQualifications{Select,ME,MTECH,MSC,PHD,DSc,DEng}
    public class Principal:PersonalDetails
    {
        private static int s_principalId=100;
        public string PrincipalId { get; }
        public PrincipalQualifications Qualification{ get; set; }
        public int YearOfExperience { get; set; }
        public DateTime DateOfJoining { get; set; }
        public Principal(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender,PrincipalQualifications qualification,int yoe):base( name, fatherName, phone, mail, dob, gender){
            s_principalId++;
            PrincipalId="PID"+s_principalId;
            Qualification=qualification;
            YearOfExperience=yoe;
            DateOfJoining=DateTime.Now.Date;
        }
        public void ShowDetails(){
        Console.WriteLine("Pricipal id: "+PrincipalId);
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Father's name: "+FatherName);
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Mail: "+Mail);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Qualification: "+Qualification);
        Console.WriteLine("YOE: "+YearOfExperience);
        Console.WriteLine("DOJ: "+DateOfJoining.ToString("dd/MM/yyyy"));
        }
    }
}