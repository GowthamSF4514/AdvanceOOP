﻿// See https://aka.ms/new-console-template for more information
using System;
namespace HierarchicalInheritance1;
class Program{
    public static void Main(string[] args)
    {
        Student student=new Student("gowtham","ponraj","42424242","gowtham@gmail.com",new DateTime(2001,10,01),Genders.Male,StudentDepartments.CSE,Degrees.BTECH,8);
        student.ShowDetails();
        Console.WriteLine("--------------------------------------");
        Teacher teacher = new Teacher("raj","kumar","979742424242","raj@gmail.com",new DateTime(1995,11,21),Genders.Male,Departments.IT,"python fundamentals",Qualifications.MTECH,2);
        teacher.ShowDetails();
        Console.WriteLine("--------------------------------------");
        Principal principal=new Principal("ram","raja","12142424242","ram@gmail.com",new DateTime(1981,02,18),Genders.Male,PrincipalQualifications.DSc,23);
        principal.ShowDetails();
    }
}
