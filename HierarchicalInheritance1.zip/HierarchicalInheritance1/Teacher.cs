using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HierarchicalInheritance1
{
    public enum Departments{Select,CSE,IT,ECE,MECH}
    public enum Qualifications{Select,BE,BTECH,ME,MTECH,MSC,PHD}
    public class Teacher:PersonalDetails
    {
        //TeacherID, Department, Subject teaching, Qualification, YearOfExperience, DateOfJoining
        private static int s_teacherId=100;
        public string TeacherId { get; }
        public Departments Department { get; set; }
        public string SubjectTeaching { get; set; }
        public Qualifications Qualification{ get; set; }
        public int YearOfExperience { get; set; }
        public DateTime DateOfJoining { get; set; }
        public Teacher(string name,string fatherName,string phone,string mail,DateTime dob,Genders gender,Departments department,string subjectTeaching,Qualifications qualification,int yoe):base( name, fatherName, phone, mail, dob, gender){
            s_teacherId++;
            TeacherId="TID"+s_teacherId;
            Department=department;
            SubjectTeaching=subjectTeaching;
            Qualification=qualification;
            YearOfExperience=yoe;
            DateOfJoining=DateTime.Now.Date;
        }
        public void ShowDetails(){
        Console.WriteLine("Teacher id: "+TeacherId);
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Father's name: "+FatherName);
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Mail: "+Mail);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Department: "+Department);
        Console.WriteLine("Subject Teaching: "+SubjectTeaching);
        Console.WriteLine("Qualificaton: "+Qualification);
        Console.WriteLine("YOE: "+YearOfExperience);
        Console.WriteLine("DOJ: "+DateOfJoining.ToString("dd/MM/yyyy"));
        }
    }
}