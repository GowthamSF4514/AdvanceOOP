﻿using System;
using System.Runtime.CompilerServices;
using System.Collections.Generic;
using System.Net;
//using static StudentsAdmission.StudentDetails;
//using StudentDetails;
namespace StudentsAdmission;
class Program
{
    static List<StudentDetails> listOfStudentDetails=new List<StudentDetails>();
    static List<DepartmentDetails> listOfDepartments=new List<DepartmentDetails>();
    static List<AdmissionDetails> listOfAdmissions=new List<AdmissionDetails>();
    static StudentDetails currentUser;
    public static void Main(string[] args)
    {
        DefaultData();
        MainMenu();
       
    }

    //method for displaying Mainmenu
    static void MainMenu()
    {
        Console.WriteLine("______Welcome_______");
        Console.WriteLine("Syncfusion College of Engineering and Technology\n");
        Submenu();
    }
    
    //submenu
    static void Submenu(){
        char choice='4';
        do
        {
            Console.WriteLine("1.Student Registration \n2.Student Login \n3.Department wise seat availability \n4.Exit\n");
            Console.Write("Enter your opinion: ");
            choice=char.Parse(Console.ReadLine());
            switch(choice)
            {
                case '1':
                {
                   Registeration();
                    break;
                }
                case '2':
                {
                    Console.Write("Enter your Student ID: ");
                    string studentId=Console.ReadLine();
                    Login(studentId);
                    
                    break;
                }
                case '3':
                {
                    SeatAvailability();
                    break;
                }
                case '4':
                {
                    Exit();
                    break;
                }
                default:
                {
                    Console.WriteLine("Invalid Option\n");
                    break;
                }
            }


        }
        while(choice!='4');

    }

    //method for student registeration for main menu
    static void Registeration()
    {
        Console.WriteLine("____STUDENT REGISTRATION_____\n");
        Console.Write("Your Name: ");
        string name=Console.ReadLine();
        Console.Write("Your Father's Name: ");
        string fatherName=Console.ReadLine();
        Console.Write("Date of birth (dd/mm/yyyy): ");
        DateTime dob=DateTime.ParseExact(Console.ReadLine(),"dd/MM/yyyy",null);
        Console.Write("Gender :");
        Genders gender=Enum.Parse<Genders>(Console.ReadLine(),true);
        Console.Write("Physics mark: ");
        int physics=int.Parse(Console.ReadLine());
        Console.Write("Chemistry mark: ");
        int chemistry=int.Parse(Console.ReadLine());
        Console.Write("Maths mark: ");
        int maths=int.Parse(Console.ReadLine());
        StudentDetails student=new StudentDetails(name,fatherName,dob,gender,physics,chemistry,maths);
        listOfStudentDetails.Add(student);
        Console.Write("Registered successfully!\n");     
    }

    //login method 
    static void Login(string id)
    {
        Console.WriteLine("______LOGIN______");
        bool flag=false;
        foreach(StudentDetails student in listOfStudentDetails)
        {
            if(id==student.ID)
            {
                Console.WriteLine("Login successfull!\n");
                currentUser=student;
                LoginSubMenu();
                flag=true;
                break;
            }
        }
        if(!flag)
        {
            Console.WriteLine("Invalid ID!\n");
        }

    }

    //after login submenu
    static void LoginSubMenu()
    {
        char choice='6';
        do
        {
            Console.WriteLine("1.Check Eligibility \n2.Show Details \n3.Take Admission \n4.Cancel Admission \n5.Show Admission Details\n6.Exit\n");
            Console.Write("Enter your opinion: ");
            choice=char.Parse(Console.ReadLine());
            switch(choice)
            {
                case '1':
                {
                   if(currentUser.IsEligible())
                   {
                        Console.WriteLine("Congratulations, you are eligible to take admission\n");
                   }
                   else
                   {
                        Console.WriteLine("Unfortunately, you are eligible to take admission\n");
                   }
                    break;
                }
                case '2':
                {
                    Console.Write("STUDENT DETAILS:");
                    ShowDetails(currentUser);
                    break;
                }
                case '3':
                {
                    Console.WriteLine("___ADMISSION ENROLLMENT____");
                    TakeAdmission();
                    break;
                }
                case '4':
                {
                    Console.WriteLine("____CANCEL ADDMISSION_____");
                    CancelAdmission(currentUser);
                    break;
                }
                case '5':
                {
                    Console.WriteLine("___ADMISSION DETAILS___");
                    ShowAdmissionDetails(currentUser);
                    break;
                }
                case '6':
                {
                    Exit();
                    break;
                }
                default:
                {
                    Console.WriteLine("Invalid Option\n");
                    break;
                }
            }


        }
        while(choice!='6');

    }

    //Take admission method
    static void TakeAdmission()
    {
        Console.WriteLine("SEATS AVAILABLE FOR NOW");
        SeatAvailability();
        Console.Write("Enter the Department ID u want take admission for: ");
        string preferedDepartmentId=Console.ReadLine();
        bool invalidDeptOrNotEligible=true;
        bool isNoSeats=false;
        bool isAdmitted=false;
        foreach(DepartmentDetails department in listOfDepartments)
        {
            if(preferedDepartmentId==department.DepartmentId && currentUser.IsEligible())
            {
                invalidDeptOrNotEligible=true;
                
                
                if(department.NumberOfSeats>0)
                {
                    if(CheckAdmitted(currentUser))
                    {
                        department.NumberOfSeats--;
                        DateTime d=DateTime.Now;
                        AdmissionDetails obj=new AdmissionDetails(currentUser.ID,department.DepartmentId,d.Date,AdmissionStatus.Admitted);
                        listOfAdmissions.Add(obj);
                        Console.WriteLine("Addmission took successfully! , ur Admission ID - "+obj.AdmissionId);
                        Console.WriteLine();
                        break;
                    }
                    else
                    {
                        Console.WriteLine("You Already took Admission");
                        break;
                    }
                    
                }
                else
                {
                    isNoSeats=true;
                }
            }
            else
            {
                invalidDeptOrNotEligible=false;
            }
            /*if(isAdmitted)
            {
                 Console.WriteLine("You Already took Admission");
                break;
                   
            }*/
        
            if(!invalidDeptOrNotEligible)
            {
                Console.WriteLine("Invalid ID or Not eligible!\n");
                break;
            }
            if(isNoSeats)
            {
                Console.WriteLine("Seats FULL for this Department");
            }

        }
    }

    //check if student has already taken admission
    static bool CheckAdmitted(StudentDetails obj)
    {
        
        foreach(AdmissionDetails admission in listOfAdmissions)
        {
            if(obj.ID==admission.AdmittedStudentId && admission.Status!=AdmissionStatus.Admitted){
                return true;
            }
        }
        return false;

    }
    
    //cancel admission
    static void CancelAdmission(StudentDetails obj)
    {
        bool flag=false;
         foreach(AdmissionDetails admission in listOfAdmissions)
        {
            if(obj.ID==admission.AdmittedStudentId && admission.Status==AdmissionStatus.Admitted)
            {
                flag= true;
                Console.WriteLine("\n________ADMISSION DETAILS____________");
                Console.WriteLine("Admission ID: "+admission.AdmissionId);
                Console.WriteLine("Admission Date: "+admission.AdmissionDate.ToString("dd/MM/yyyy"));
                Console.WriteLine("Admitted Department ID: "+admission.AdmittedDepartmentId);
                foreach(DepartmentDetails dept in listOfDepartments)
                {
                    if(dept.DepartmentId==admission.AdmittedDepartmentId)
                    {
                        Console.WriteLine("Admitted Department Name"+dept.DepartmentName);
                        dept.NumberOfSeats++;
                    }
                }
                admission.Status=AdmissionStatus.Cancelled;
                break;
            }
        }        
            if(flag)
            {
                Console.WriteLine("Admission Cancelled Successfully!\n");
            }
            else
            {
                Console.WriteLine("You Haven't took any Admission yet");
            }
    
    }
    //show admission details of current user logged in
    static void ShowAdmissionDetails(StudentDetails obj)
    {
        bool flag=false;
        //Console.Write("Enter ur Admission ID: ");
        //string admissionId=Console.ReadLine();
        foreach(AdmissionDetails admissions in listOfAdmissions){
            if(admissions.AdmittedStudentId==obj.ID){
                flag=true;
                Console.WriteLine("Admission ID: "+admissions.AdmissionId);
                Console.WriteLine("Student ID: "+obj.ID);
                Console.WriteLine("Department ID: "+admissions.AdmittedDepartmentId);
                foreach(DepartmentDetails dept in listOfDepartments)
                {
                    if(dept.DepartmentId==admissions.AdmittedDepartmentId)
                    {   
                        Console.WriteLine("Department: "+dept.DepartmentName);
                        break;
                    }
                }
                
                Console.WriteLine("Admission Date: "+admissions.AdmissionDate.ToString("dd/MM/yyyy"));
                Console.WriteLine("Admission Status: "+admissions.Status);
            }
        }
        if(!flag)
        {
            Console.WriteLine("You haven't took any Admission \n");
        }
    }

    //exit method to print exit message
    static void Exit(){
        Console.WriteLine("_____________EXITED_______________\n");
    }

    //method to check department wise seats availability
    static void SeatAvailability(){
        Console.WriteLine("DEPARTMENT ID ----------- DEPARTMENT_NAME ------------ SEATS AVAILABLE");
        foreach(DepartmentDetails dept in listOfDepartments){
            Console.Write(dept.DepartmentId);
            Console.Write("\t\t-\t\t");
            Console.Write(dept.DepartmentName);
            Console.Write("\t\t-\t\t");
            Console.Write(dept.NumberOfSeats);
            Console.WriteLine();
        }
        Console.WriteLine();
    }

    //method to initialize all given default dats
    static void DefaultData()
    {
        StudentDetails obj1=new StudentDetails("Ravichandran E","Ettapparajan",	new DateTime(1999,11,11),Genders.Male,95,95,95);
        listOfStudentDetails.Add(obj1);
        StudentDetails obj2=new StudentDetails("Baskaran S","Sethurajan",new DateTime(1999,11,11),Genders.Male,95,95,95);
        listOfStudentDetails.Add(obj2);
        DepartmentDetails dept1=new DepartmentDetails("EEE",29);
        listOfDepartments.Add(dept1);
        DepartmentDetails dept2=new DepartmentDetails("CSE",29);
        listOfDepartments.Add(dept2);
        DepartmentDetails dept3=new DepartmentDetails("MECH",30);
        listOfDepartments.Add(dept3);
        DepartmentDetails dept4=new DepartmentDetails("ECE",30);
        listOfDepartments.Add(dept4);
        AdmissionDetails admission1=new AdmissionDetails("SF3001","DID101",new DateTime(2022,05,11),AdmissionStatus.Admitted);
        listOfAdmissions.Add(admission1);
        AdmissionDetails admission2=new AdmissionDetails("SF3002","DID102",new DateTime(2022,05,12),AdmissionStatus.Admitted);
        listOfAdmissions.Add(admission2);
        
    }
    //show details of students
    static void ShowDetails(StudentDetails obj){
        Console.WriteLine("Your Name: "+obj.Name);
        Console.WriteLine("Your Father's name: "+obj.FatherName);
        Console.WriteLine("Your Dob: "+obj.DOB.ToString("dd/MM/yyyy"));
        Console.WriteLine("Your Gender: "+obj.Gender);
        Console.WriteLine("Your Physics mark: "+obj.Physics);
        Console.WriteLine("Your Chemistry mark: "+obj.Chemistry);
        Console.WriteLine("Your Maths mark: "+obj.Maths);
    }

        
    
}



    

