using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsAdmission
{
    public class DepartmentDetails
    {
        /// <summary>
        /// private static field to autogenerate department id
        /// </summary>
        static private int d_Id=100;
        /// <summary>
        /// string property to store department id
        /// </summary>
        /// <value></value>
        public string DepartmentId { get; }
        /// <summary>
        /// string property to store dept name
        /// </summary>
        /// <value></value>
        public string DepartmentName { get; set; }
        /// <summary>
        /// property to store no of seats available
        /// </summary>
        /// <value>int</value>
        public int NumberOfSeats { get; set; }
        /// <summary>
        /// param constructor to initialize departmentDetails object
        /// </summary>
        /// <param name="departmentName">string - dept name</param>
        /// <param name="numberOfSeats">int - no of seats available</param>
        public DepartmentDetails(string departmentName,int numberOfSeats)
        {
            d_Id++;
            DepartmentId="DID"+d_Id;
            DepartmentName=departmentName;
            NumberOfSeats=numberOfSeats;
        }
    }
}