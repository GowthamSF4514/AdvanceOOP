using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsAdmission
{
    public enum AdmissionStatus{Select,Admitted,Cancelled}
    public class AdmissionDetails
    {
        /// <summary>
        /// static private field to autogenerate id
        /// </summary>
        static private int a_Id=1000;
        /// <summary>
        /// property to store admission ID
        /// </summary>
        /// <value>read only</value>
        public string AdmissionId { get; }
        /// <summary>
        /// datetime property to store admission date
        /// </summary>
        /// <value></value>
        public DateTime AdmissionDate {get; set;}
        /// <summary>
        /// enum type property to store admission status
        /// </summary>
        /// <value>admitted or cancelled</value>
        public AdmissionStatus Status{get; set;}
        /// <summary>
        /// property to store admitted student id
        /// </summary>
        /// <value></value>
        public string AdmittedStudentId { get; set; }
        /// <summary>
        /// property to store admitted student department id
        /// </summary>
        /// <value></value>
        public string AdmittedDepartmentId { get; set; }
        /// <summary>
        /// parametrized constructor to intialize admissionDetails object
        /// </summary>
        /// <param name="studentId"> student id of type string</param>
        /// <param name="departmentId">department id of type string</param>
        /// <param name="date">admission date of datetime object</param>
        /// <param name="status">status of admission</param>
        public AdmissionDetails(string studentId,string departmentId,DateTime date,AdmissionStatus status)
        {
            a_Id++;
            AdmissionId="AID"+a_Id;
            AdmissionDate=date;
            Status=status;
            AdmittedStudentId=studentId;
            AdmittedDepartmentId=departmentId;
        }
    }
}