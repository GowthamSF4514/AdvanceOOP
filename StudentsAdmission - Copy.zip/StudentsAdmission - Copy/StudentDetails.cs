using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;

namespace StudentsAdmission
{
    /*Namespaces may contains
        1.Namespace
        2. Classes
        3.Enumeration types-enum
        4.Structures- strucy
        5.Delegates
        6.Records
        */
    /// <summary>
    /// Class StudentDetails used to create instance for student <see cref="StudentDetails"/> 
    /// Refer documentation on <see href="www.syncfusion.com"/> 
    /// 
    /// </summary>
    /// <summary>
    /// Datatype Gender used to a slect a instance of <see cref="StudenDetails"/> Gender Information 
    /// </summary> <summary>
    /// </summary>
    public enum Genders{Select,Male,Female,Trasgender}
    public class StudentDetails
    {       
        
        /// <summary>
        /// Static field s_id is used to autoincrement ID of the instance of <see cref="StudentDetails"/> 
        /// </summary>
        public static int s_Id=3000; //field to auto increment the ID
        
        /// <summary>
        /// ID property used to hold a student's ID of instance of <see cref="StudentDetails"/>
        /// </summary>
        public string ID { get;  } // read only property
        
        /// <summary>
        /// first name property used to hold firstname of instance of <see cref="StudentDetails"/>
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// father name property used to hold father name of instance of <see cref="StudentDetails"/>
        /// </summary>
        public string FatherName { get; set; }
        
        /// <summary>
        /// Date of birth Datetime propery to hold dob of student of instance of <see cref="StudentDetails"/>
        /// </summary>
        ///<value> dd/MM/yyyy</value>
        public DateTime DOB { get; set; }

        /// <summary>
        /// Gender type property to hold gender of instance of <see cref="StudentDetails"/> 
        /// </summary> 
        public Genders Gender {get; set;}
        
        /// <summary>
        /// Physics property to hold physics mark of instance of <see cref="StudentDetails"/> 
        /// </summary> 
        /// <value>0 to 100</value>
        public int Physics { get; set; } 
        
        /// <summary>
        /// Chemistry property to hold chemistry mark of instance of <see cref="StudentDetails"/>
        /// </summary>
        /// <value>0 to 100</value>
        public int Chemistry { get; set; }

        /// <summary>
        /// Maths property to hold maths mark of instance of <see cref="StudentDetails"/>
        /// </summary> <summary>
        /// 
        /// </summary>
        /// <value>0 to 100</value>
        public int Maths { get; set; }

        //default constructor
        /// <summary>
        /// Constructor StudentDetails used to intialize default values to its properties
        /// </summary>
        public StudentDetails()
        {
            

        }

        /// <summary>
        /// Constructor StudentDetails used to initialize parameter value to its properties
        /// </summary>
        /// <param name="name">name param used to initialize value to its associated property</param>
        /// <param name="fatherName">fathername param used to initialize value to its associated property</param>
        /// <param name="dob">dob param used to initialize value to its associated property</param>
        /// <param name="gender">gender param used to initialize value to its associated property</param>
        /// <param name="physics">physics param used to initialize value to its associated property</param>
        /// <param name="chemistry">chemistry param used to initialize value to its associated property</param>
        /// <param name="maths">maths param used to initialize value to its associated property</param> <summary>
        /// 
        /// </summary>
        public StudentDetails(string name,string fatherName, DateTime dob, Genders gender, int physics, int chemistry,int maths)
        {
            s_Id++;
            ID="SF"+s_Id;
            Name=name;
            FatherName=fatherName;
            DOB=dob;
            Gender=gender;
            Physics=physics;
            Chemistry=chemistry;
            Maths=maths;

        }
        
        /// <summary>
        /// IsEligible method of <see cref="StudentDetails"/> to check if instance is eligible or not per cutoff
        /// </summary>
        /// <param name="cutoff"> value to check against avg of PCM </param>
        /// <returns>bool value - true or false </returns>
        public bool IsEligible()
        {
            double avg=(double)(Physics+Chemistry+Maths)/3;
            if(avg>=75)
            {
                return true;
            }
            else
            {
                return false;
            }

        }
    }
}