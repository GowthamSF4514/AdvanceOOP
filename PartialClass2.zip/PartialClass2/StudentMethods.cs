using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass2
{
    public partial class StudentInfo
    {
        public void Display(){
            Console.WriteLine("----------Student details-------------");
            Console.WriteLine("Name: "+Name);
            Console.WriteLine("ID: "+StudentId);
            Console.WriteLine("Mobile: "+Mobile);
            Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
            Console.WriteLine("Physics Marks: "+Physics);
            Console.WriteLine("Chemistry Marks: "+Chemistry);
            Console.WriteLine("Maths Marks: "+Maths);
        }
        public void Calculate(){
            Console.WriteLine("Total: "+Physics+Chemistry+Maths);
            Console.WriteLine("Percentage: "+Math.Round((Physics+Chemistry+Maths)/300*100,2));
        }
    }
}