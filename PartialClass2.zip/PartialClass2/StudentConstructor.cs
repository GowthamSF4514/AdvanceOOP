using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass2
{
    public partial class StudentInfo
    {
        public StudentInfo(string name,Genders gender,DateTime dob,string mobile,double phy,double chem,double maths){
                StudentId="SID"+ ++s_studentId;
                Name=name;
                Gender=gender;
                Dob=dob;
                Mobile=mobile;
                Physics=phy;
                Chemistry=chem;
                Maths=maths;
            }
    }
}