﻿using System;
namespace PartialClass2;
class Program{
    public static void Main(string[] args)
    {
        StudentInfo student = new StudentInfo("gowtham",StudentInfo.Genders.Male,new DateTime(2001,10,01),"424342424",90,82,75);
        student.Display();
        student.Calculate();
    }
}