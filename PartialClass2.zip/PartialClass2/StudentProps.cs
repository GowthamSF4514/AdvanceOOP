using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PartialClass2
{
    public partial class StudentInfo
    {
        public enum Genders{Select,Male,Female}
            public static int s_studentId=100;
            public string StudentId { get; }
            public string Name { get; set; }
            public string Mobile { get; set; }
            public Genders Gender { get; set; }
            public DateTime Dob { get; set; }
            public double Physics { get; set; }
            public double Chemistry { get; set; }
            public double Maths { get; set; }
    }
}