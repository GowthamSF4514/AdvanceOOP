using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;

namespace Hierarchical2
{
    public enum EmployeeType{Fulltime, Temporary}
    public class PermanentEmployee:SalaryInfo
    {
        private static int s_empId=100;
        public static double totalSalary=0;
        public static double DA=0.2*BasicSalary;
        public string EmployeeId { get; set; }
        public static double HRA=0.18*BasicSalary;
        public static double PF=0.1*BasicSalary;
        public static double TotalSalary { get{return totalSalary;} set{totalSalary=value;} }
        public static void Calculate(){
            totalSalary=DA+HRA+PF+BasicSalary;
        }
        public static void ShowSalary(){
            Console.WriteLine(TotalSalary);
        }
        public PermanentEmployee(double totalSalary){
            s_empId++;
            EmployeeId="PID"+s_empId;
            TotalSalary=totalSalary;
        }
    }
}