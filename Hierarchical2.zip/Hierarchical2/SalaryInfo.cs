using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hierarchical2
{
    public class SalaryInfo
    {
        public static double BasicSalary { get; set; }
        public static int Month { get; set; }
    }
}