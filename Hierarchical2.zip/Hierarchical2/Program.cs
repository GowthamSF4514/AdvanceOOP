﻿using System;
namespace Hierarchical2;
using static Hierarchical2.PermanentEmployee;
class Program{
    public static void Main(string[] args)
    {
        PermanentEmployee emp1=new PermanentEmployee(21500);
        PermanentEmployee emp2=new PermanentEmployee(27500);
        TemporaryEmployee emp3=new TemporaryEmployee(12000);
        TemporaryEmployee emp4=new TemporaryEmployee(10000);
        
    }
}
