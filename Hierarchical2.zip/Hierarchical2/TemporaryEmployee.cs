using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hierarchical2
{
    
    public class TemporaryEmployee:SalaryInfo
    {
        private static int s_empId=100;
        public static double totalSalary=0;
        public static double DA=0.15*BasicSalary;
        public string EmployeeId { get; set; }
        public static double HRA=0.13*BasicSalary;
        
        public static double TotalSalary { get{return totalSalary;} set{totalSalary=value;} }
        public void Calculate(){
            totalSalary=DA+HRA+BasicSalary;
        }
        public static void ShowSalary(){
            Console.WriteLine(TotalSalary);
        }
        public TemporaryEmployee(double totalSalary){
            s_empId++;
            EmployeeId="TID"+s_empId;
            TotalSalary=totalSalary;
        }
    }
}