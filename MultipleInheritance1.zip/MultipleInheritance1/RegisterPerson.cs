using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritance1
{
    public class RegisterPerson:PersonalDetails,IShowData,IFamilyInfo
    {
        private static int s_registrationNumber=100;
        public string FatherName{get; set;}
        public string MotherName { get; set; } 
        public string HouseAddress { get; set; }
        public int NoOfSiblings { get; set; }
        public int RegistrationNumber { get; }
        public DateTime DateOfRegistration { get; set; }
        public RegisterPerson(string name,Genders gender,DateTime dob,string phone,string mobile,MaritalStatus maritalStatus,string fatherName,string motherName,string address,int noOfSiblings):base( name, gender, dob, phone, mobile, maritalStatus){
            s_registrationNumber++;
            RegistrationNumber=s_registrationNumber;
            FatherName=fatherName;
            MotherName=motherName;
            HouseAddress=address;
            NoOfSiblings=noOfSiblings;
            DateOfRegistration=DateTime.Now.Date;
        }
        public void ShowInfo(){
            Console.WriteLine("Registraion Number: "+RegistrationNumber);
            Console.WriteLine("Name : "+Name);
            Console.WriteLine("Gender: "+Gender);
            Console.WriteLine("Father Name: "+FatherName);
            Console.WriteLine("Mother Name: "+MotherName);
            Console.WriteLine("Dob : "+Dob.ToString("dd/MM/yyyy"));
            Console.WriteLine("Mobile Number: "+Mobile);
            Console.WriteLine("Phone Number: "+Phone);
            Console.WriteLine("Martial Status: "+MaritalStatus);
            Console.WriteLine("Address: "+HouseAddress);
            Console.WriteLine("Number of sibling: "+NoOfSiblings);
            Console.WriteLine("Registered Date : "+DateOfRegistration.ToString("dd/MM/yyyy"));

        }
    }
}