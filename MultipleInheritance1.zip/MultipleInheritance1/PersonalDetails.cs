using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritance1
{
    public enum Genders{Select,Male,Female}
    public enum MaritalStatus { Select,Married,Single }
    public class PersonalDetails:IShowData
    {
        public string Name { get; set; }
        public Genders Gender { get; set; }
        public DateTime Dob { get; set; }
        public string Phone { get; set; }
        public string Mobile { get; set; }
        public MaritalStatus MaritalStatus { get; set; }
        
        
        public PersonalDetails(string name,Genders gender,DateTime dob,string phone,string mobile,MaritalStatus maritalStatus){
            Name=name;
            Gender=gender;
            Dob=dob;
            Phone=phone;
            Mobile=mobile;
            MaritalStatus=maritalStatus;
           
        }
        public void ShowInfo(){
        Console.WriteLine("Name: "+Name);
        Console.WriteLine("Gender: "+Gender);
        Console.WriteLine("Dob: "+Dob.ToString("dd/MM/yyyy"));
        Console.WriteLine("Phone: "+Phone);
        Console.WriteLine("Mobile: "+Mobile);
        Console.WriteLine("Marital status: "+MaritalStatus);
        }
    }
}