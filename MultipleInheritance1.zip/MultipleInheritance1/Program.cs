﻿using System;
namespace MultipleInheritance1;
class Program{
    public static void Main(string[] args)
    {
        RegisterPerson person1=new RegisterPerson("gowtham",Genders.Male,new DateTime(2001,10,01),"232323","98789787",MaritalStatus.Single,"ponraj","selvi","avadi",2);
        RegisterPerson person2=new RegisterPerson("raj",Genders.Male,new DateTime(2002,05,30),"423223","2342342",MaritalStatus.Single,"raj","raj","avadi",2);
        person1.ShowInfo();
        Console.WriteLine("------------------------");
        person2.ShowInfo();
    }
}