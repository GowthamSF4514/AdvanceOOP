using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MultipleInheritance1
{
    public interface IShowData
    {
        public void ShowInfo();
    }
}