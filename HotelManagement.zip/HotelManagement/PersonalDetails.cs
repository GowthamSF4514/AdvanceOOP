using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement
{
    public enum FoodTypes{Select,Veg,NonVeg}
    public enum Genders{Select,Male, Female, Transgender}
    public class PersonalDetails
    {
        public string UserName { get; set; }
        public string MobileNumber { get; set; } 
        public string AadharNumber { get; set; }   
        public string Address { get; set; }
        public FoodTypes FoodType { get; set; }
        public Genders Gender { get; set; }
        public PersonalDetails(string userName,string mobileNumber,string aadharNumber,string address,FoodTypes foodType,Genders gender){
            UserName=userName;
            MobileNumber=mobileNumber;
            AadharNumber=aadharNumber;
            Address=address;
            FoodType=foodType;
            Gender=gender;
        }
    }
}