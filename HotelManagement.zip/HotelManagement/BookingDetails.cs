using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement
{
    //public enum BookingStatusus {Default, Initiated, Booked, Cancelled}
    public class BookingDetails
    {
        private static int s_bookingId=100;
        public string BookingId { get;  }
        public string UserId { get; set; }
        public double TotalPrice { get; set; }
        public DateTime DateOfBooking { get; set; }
        public BookingStatusus BookingStatus { get; set; }
        public BookingDetails(string userId,double totalPrice,DateTime dateOfBooking,BookingStatusus bookingStatus){
            s_bookingId++;
            BookingId="BID"+s_bookingId;
            UserId=userId;
            TotalPrice=totalPrice;
            DateOfBooking=dateOfBooking;
            BookingStatus=bookingStatus;
        }
    }
}