using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement
{
    public enum BookingStatusus{Default, Initiated, Booked, Cancelled}
    public class RoomSelection
    {
        private static int s_selectionId=1000;
        public string SelectionId { get; }
        public string RoomId { get; set; }
        public string BookingId { get; set; }
        public DateTime StayingDateFrom { get; set; }
         public DateTime StayingDateTo { get; set; }
         public double Price { get; set; }
         public double NumberOfDays { get; set; }
         public BookingStatusus BookingStatus { get; set; }
         public RoomSelection(string bookingId,string roomId,DateTime stayingDateFrom, DateTime stayingDateTo,double price,double numberOfDays,BookingStatusus bookingStatus){
            s_selectionId++;
            SelectionId="SID"+s_selectionId;
            RoomId=roomId;
            BookingId=bookingId;
            StayingDateFrom=stayingDateFrom;
            StayingDateTo=stayingDateTo;
            Price=price;
            NumberOfDays=numberOfDays;
            BookingStatus=bookingStatus;
         }
    }
}