using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Threading.Tasks;

namespace HotelManagement
{
    public partial class MyList<Type>
    {
        private int _count;
        private int _capacity;
        public int Count { get{return _count;} }
        public int Capacity { get{return _capacity;} }
        private Type[] _array;
        public MyList(){
            _count=0;
            _capacity=0;
            _array=new Type[_capacity];
        }
        public MyList(int size){
            _count=0;
            _capacity=size;
            _array=new Type[_capacity];
        }
        public void Add(Type element){
            if(_capacity==_count){
                grow();
            }
            _array[_count]=element;
            _count++;
        }
        public void grow(){
            _capacity*=4+1;
            Type[] temp=new Type[_capacity];
            for(int i=0;i<_count;i++){
                temp[i]=_array[i];
            }
            _array=temp;
        }
        public Type this[int index] { get{return _array[index];} set{_array[index]=value;} }

    }
}