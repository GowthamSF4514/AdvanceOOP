using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement
{
    public class UserRegistration:PersonalDetails,IWalletManager
    {
        
       private double _balance;
       private static int s_userId=1000;
       public double WalletBalance { get{return _balance;} }
       public string UserId { get;}
       public void WalletRecharge(double amount){
            _balance+=amount;
       }
       public void DeductBalance(double amount){
            _balance-=amount;
       }
       public UserRegistration(string userName,string mobileNumber,string aadharNumber,string address,FoodTypes foodType,Genders gender,double balance):base( userName, mobileNumber, aadharNumber, address, foodType, gender){
        s_userId++;
        UserId="SF"+s_userId;
        _balance=balance;
       }
        
    }
}