using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.Design;
using System.Linq;
using System.Threading.Tasks;

namespace HotelManagement
{
    public class Operations
    {
        public static List<UserRegistration> listOfUserRegistration = new List<UserRegistration>();
        public static List<RoomDetails> listOfRoomDetails = new List<RoomDetails>();
        public static List<BookingDetails> listOfBookingDetails = new List<BookingDetails>();
        public static List<RoomSelection> listOfRoomSelection = new List<RoomSelection>();
        public static UserRegistration currentUser;

        public static void DefaultDatas()
        {
            //method for adding default datas for testing 
            //adding user registration obj its respective list
            UserRegistration user1 = new UserRegistration("Ravichandran", "995875777", "347777378383", "Chennai", FoodTypes.Veg, Genders.Male, 5000);
            listOfUserRegistration.Add(user1);
            UserRegistration user2 = new UserRegistration("Baskaran", "448844848", "474777477477", "Chennai", FoodTypes.NonVeg, Genders.Male, 6000);
            listOfUserRegistration.Add(user2);

            //adding roomDetails obj to its respective list
            RoomDetails room1 = new RoomDetails(RoomTypes.Standard, 2, 500);
            listOfRoomDetails.Add(room1);
            RoomDetails room2 = new RoomDetails(RoomTypes.Standard, 4, 700);
            listOfRoomDetails.Add(room2);
            RoomDetails room3 = new RoomDetails(RoomTypes.Standard, 2, 500);
            listOfRoomDetails.Add(room3);
            RoomDetails room4 = new RoomDetails(RoomTypes.Standard, 2, 500);
            listOfRoomDetails.Add(room4);
            RoomDetails room5 = new RoomDetails(RoomTypes.Standard, 2, 500);
            listOfRoomDetails.Add(room5);
            RoomDetails room6 = new RoomDetails(RoomTypes.Delux, 2, 1000);
            listOfRoomDetails.Add(room6);
            RoomDetails room7 = new RoomDetails(RoomTypes.Delux, 2, 1000);
            listOfRoomDetails.Add(room7);
            RoomDetails room8 = new RoomDetails(RoomTypes.Delux, 4, 1400);
            listOfRoomDetails.Add(room8);
            RoomDetails room9 = new RoomDetails(RoomTypes.Delux, 4, 1400);
            listOfRoomDetails.Add(room9);
            RoomDetails room10 = new RoomDetails(RoomTypes.Suit, 2, 2000);
            listOfRoomDetails.Add(room10);
            RoomDetails room11 = new RoomDetails(RoomTypes.Suit, 2, 2000);
            listOfRoomDetails.Add(room11);
            RoomDetails room12 = new RoomDetails(RoomTypes.Suit, 2, 2000);
            listOfRoomDetails.Add(room12);
            RoomDetails room13 = new RoomDetails(RoomTypes.Suit, 4, 2500);
            listOfRoomDetails.Add(room13);

            //adding selectionDetails obj to its respective list
            RoomSelection selection1 = new RoomSelection("BID101", "RID101", DateTime.ParseExact("11/11/2022 06:00 AM", "dd/MM/yyyy hh:mm tt", null), DateTime.ParseExact("12/11/2022 02:00 PM", "dd/MM/yyyy hh:mm tt", null), 750, 1.5, BookingStatusus.Booked);
            listOfRoomSelection.Add(selection1);
            RoomSelection selection2 = new RoomSelection("BID101", "RID102", DateTime.ParseExact("11/11/2022 10:00 AM", "dd/MM/yyyy hh:mm tt", null), DateTime.ParseExact("12/11/2022 09:00 AM", "dd/MM/yyyy hh:mm tt", null), 700, 1, BookingStatusus.Booked);
            listOfRoomSelection.Add(selection2);
            RoomSelection selection3 = new RoomSelection("BID102", "RID103", DateTime.ParseExact("12/11/2022 09:00 AM", "dd/MM/yyyy hh:mm tt", null), DateTime.ParseExact("13/11/2022 09:00 AM", "dd/MM/yyyy hh:mm tt", null), 500, 1, BookingStatusus.Cancelled);
            listOfRoomSelection.Add(selection3);
            RoomSelection selection4 = new RoomSelection("BID102", "RID106", DateTime.ParseExact("12/11/2022 06:00 AM", "dd/MM/yyyy hh:mm tt", null), DateTime.ParseExact("13/11/2022 12:30 AM", "dd/MM/yyyy hh:mm tt", null), 1500, 1.5, BookingStatusus.Cancelled);
            listOfRoomSelection.Add(selection4);

            //adding bookingDetails obj to its respective list
            BookingDetails booking1 = new BookingDetails("SF1001", 1450, DateTime.ParseExact("10/11/2022", "dd/MM/yyyy", null), BookingStatusus.Booked);
            BookingDetails booking2 = new BookingDetails("SF1002", 2000, DateTime.ParseExact("10/11/2022", "dd/MM/yyyy", null), BookingStatusus.Cancelled);
            listOfBookingDetails.Add(booking1);
            listOfBookingDetails.Add(booking2);
        }

        public static void Mainmenu()
        {
            //display mainmenu contents to user
            Console.WriteLine("-------------------WELCOME TO SYNCSTAYS----------------------");
            Console.WriteLine();
            int choice;
            do
            {
                Console.WriteLine("-----------MAIN MENU-------------");
                Console.WriteLine();
                //ask user his choice
                Console.WriteLine("1.	User Registration\n2.	User Login\n3.	Exit");
                Console.WriteLine();
                Console.Write("Please enter your choice: ");
                choice = int.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        {
                            //go to user registration method
                            UserRegistration();
                            break;
                        }
                    case 2:
                        {
                            //go to login method
                            Login();
                            break;
                        }
                    case 3:
                        {
                            Console.WriteLine("---------------EXITED---------------");
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid Choice! please enter correct options displayed above. ");
                            break;
                        }
                }
            } while (choice != 3);
        }

        public static void UserRegistration()
        {
            //ask user his details
            Console.WriteLine("--------REGISTRATION PAGE-------");
            Console.WriteLine("Please enter your details below!");
            Console.Write("Username: ");
            string userName = Console.ReadLine();
            Console.Write("Mobile Number: +91 ");
            string mobileNumber = Console.ReadLine();
            Console.Write("Aadhar Number (if you are an NRI, please visit SyncStays.NRIguidelines): ");
            string aadharNumber = Console.ReadLine();
            Console.Write("Permanent Address: ");
            string address = Console.ReadLine();
            Console.Write("Food Type: ");
            FoodTypes foodType = Enum.Parse<FoodTypes>(Console.ReadLine(), true);
            Console.Write("Gender: ");
            Genders gender = Enum.Parse<Genders>(Console.ReadLine(), true);
            Console.Write("Enter the amount you'd like to deposit in your wallet balace: Rs.");
            double balace = double.Parse(Console.ReadLine());
            //create userRegistration obj and add it to list
            UserRegistration user = new UserRegistration(userName, mobileNumber, aadharNumber, address, foodType, gender, balace);
            listOfUserRegistration.Add(user);
            //display registered user userID
            Console.WriteLine("User registered successfully! Your User ID is " + user.UserId);
        }

        public static void Login()
        {
            Console.WriteLine("-----------------LOGIN------------------");
            //ask user his user ID
            Console.WriteLine("Please enter your User ID.");
            Console.Write("User ID: ");
            string userId = Console.ReadLine().ToUpper();
            bool isValidUserId = false;
            foreach (UserRegistration user in listOfUserRegistration)
            {
                //traverse user reg list to match user entered User ID
                if (user.UserId == userId)
                {
                    Console.WriteLine("Login Successfull!");
                    isValidUserId = true;
                    currentUser = user;
                    //go to submenu()
                    Submenu();
                }
            }
            //if user ID not found then say
            if (!isValidUserId)
            {
                Console.WriteLine("Invalid User ID!");
                Console.WriteLine();
            }
        }

        public static void Submenu()
        {
            //display submenu contents
            char choice;
            do
            {
                //ask user his choice
                Console.WriteLine("-----------------SUBMENU---------------");
                Console.WriteLine();
                Console.WriteLine("a.	View Customer Profile\nb.	Book Room\nc.	Modify Booking\nd.	Cancel Booking\ne.	Booking History\nf.	Wallet Recharge\ng.	Show WalletBalance\nh.	Exit ");
                Console.Write("Enter your choice: ");
                choice = char.Parse(Console.ReadLine().ToLower());
                switch (choice)
                {
                    case 'a':
                        {
                            ViewCustomerProfile();
                            break;
                        }
                    case 'b':
                        {
                            BookRoom();
                            break;
                        }
                    case 'c':
                        {
                            ModifyBooking();
                            break;
                        }
                    case 'd':
                        {
                            CancelBooking();
                            break;
                        }
                    case 'e':
                        {
                            BookingHistory();
                            break;
                        }
                    case 'f':
                        {
                            RechargeWallet();
                            break;
                        }
                    case 'g':
                        {
                            ShowWalletBalance();
                            break;
                        }
                    case 'h':
                        {
                            Console.WriteLine("SubMenu exited!");
                            Console.WriteLine();
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("Invalid choice, please enter a valid choice from above");
                            Console.WriteLine();
                            break;
                        }
                }

            } while (choice != 'h');
        }

        public static void ViewCustomerProfile()
        {
            //display the details of customer
            Console.WriteLine("----------------------USER DETAILS---------------------------");
            Console.WriteLine("User ID: " + currentUser.UserId);
            Console.WriteLine("User Name: " + currentUser.UserName);
            Console.WriteLine("Mobile Number: +91 " + currentUser.MobileNumber);
            Console.WriteLine("Address: " + currentUser.Address);
            Console.WriteLine("User prefered food type: " + currentUser.FoodType);
            Console.WriteLine("Gender: " + currentUser.Gender);
            ShowWalletBalance();
        }

        public static void ShowWalletBalance()
        {
            //displa users current balance
            Console.WriteLine("User ID " + currentUser.UserId + " Wallet balance is Rs." + currentUser.WalletBalance);
            Console.WriteLine();
        }
        public static void RechargeWallet()
        {
            //recharge user's wallet balance
            //ask user the amount they wanna recharge
            Console.Write("Enter the amount u wanna recharge your wallet: Rs.");
            double amount = double.Parse(Console.ReadLine());
            currentUser.WalletRecharge(amount);
            ShowWalletBalance();
        }
        public static void BookingHistory()
        {
            Console.WriteLine("---------------------BOOKING HISTORY-------------------");
            //traverse through booking details list to match user id
            bool isBookingMade = false;
            foreach (BookingDetails booking in listOfBookingDetails)
            {
                if (currentUser.UserId == booking.UserId)
                {
                    isBookingMade = true;
                    Console.WriteLine("Booking ID: " + booking.BookingId);
                    Console.WriteLine("Total Price: Rs." + booking.TotalPrice);
                    Console.WriteLine("Date Booked: " + booking.DateOfBooking.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Booking Status: " + booking.BookingStatus);
                    Console.WriteLine("----------------------------------------------------");
                }
            }
            //at the end of the loop , if no booking found then say
            if (!isBookingMade)
            {
                Console.WriteLine("You haven't made any bookings yet!. To Book, please visit Option 'b'- Book Room ");
                Console.WriteLine();
            }
            else
            {
                //else, ask user to enter booking id to see room details
                //if booking invalid print "invalid booking id"
                bool isValidBookingId = false;
                Console.Write("Enter Booking ID to see the room details of: ");
                string bookingId = Console.ReadLine();
                foreach (RoomSelection selection in listOfRoomSelection)
                {
                    //traverse room selction list to match with user entered booking id
                    if (bookingId == selection.BookingId)
                    {
                        foreach (BookingDetails booking in listOfBookingDetails)
                        {
                            if (booking.BookingId == bookingId && booking.UserId == currentUser.UserId)
                            {
                                isValidBookingId = true;
                                //print room selection details
                                Console.WriteLine("Selection ID: " + selection.SelectionId);
                                Console.WriteLine("Room ID: " + selection.RoomId);
                                Console.WriteLine("Date Staying From: " + selection.StayingDateFrom.ToString("dd/MM/yyyy hh:mm tt"));
                                Console.WriteLine("Date Staying till: " + selection.StayingDateTo.ToString("dd/MM/yyyy hh:mm tt"));
                                Console.WriteLine("Price : Rs." + selection.Price);
                                Console.WriteLine("Number of Days stayed: " + selection.NumberOfDays);
                                Console.WriteLine("Booking Status: " + selection.BookingStatus);
                                Console.WriteLine("----------------------------------------------");
                            }
                        }
                    }
                }
                //at the end the loop , if no booking id matched then say
                if (!isValidBookingId)
                {
                    Console.WriteLine("Invalid Booking ID, please select valid any Booking ID listed above!");
                    Console.WriteLine();
                }
            }
        }
        public static void DisplayRooms()
        {
            //method of display room details
            Console.WriteLine("------------------ROOM DETAILS--------------------");
            string line = "-----------------------------------------------";
            Console.WriteLine($"|{"ROOM ID",-10}|{"ROOM TYPE",-10}|{"NO OF BEDS",-10}|{"PRICE PER DAY",-10}|");
            Console.WriteLine(line);
            foreach (RoomDetails room in listOfRoomDetails)
            {
                Console.WriteLine($"|{room.RoomId,-10}|{room.RoomType,-10}|{room.NumberOfBeds,-10}|{room.PricePerDay,-10}|");
                Console.WriteLine(line);
            }
        }
        public static void BookRoom()
        {
            //create temporary booking obj
            BookingDetails tempBook = new BookingDetails(currentUser.UserId, 0, DateTime.Now.Date, BookingStatusus.Initiated);
            //create temporary room selection list
            List<RoomSelection> tempListOfRoomSelection = new List<RoomSelection>();
            //keep looping until user enters "no"
            string userChoice = "yes";
            do
            {
                //display list of available room types
                DisplayRooms();
                //ask user to enter room id , book date from and book date to and no od days of booking
                Console.Write("Enter the Room ID you wanna book: ");
                string roomId = Console.ReadLine();
                Console.Write("Enter the Date and time you wanna stay from (dd/MM/yyyy hh:mm tt): ");
                DateTime stayFrom = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy hh:mm tt", null);
                Console.Write("Enter the Date and time you wanna stay till (dd/MM/yyyy hh:mm tt): ");
                DateTime stayTill = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy hh:mm tt", null);
                TimeSpan ts = stayTill - stayFrom;
                double noOfDaysOfBooking = ts.Days;
                //check if valid room id
                int isValidRoomId = int.Parse(roomId.Remove(0, 3));
                if (isValidRoomId >= 101 && isValidRoomId <= 113)
                {
                    bool isDatesNotAvailable = false;
                    //traverse room selection list to check if it is booked using above details
                    foreach (RoomSelection selection in listOfRoomSelection)
                    {
                        if (selection.RoomId == roomId)
                        {
                            //condition for room available , either we are staying before their arrival or staying only after their arrival and has sufficient balance in acc
                            if ((selection.StayingDateFrom > stayFrom && selection.StayingDateFrom > stayTill) || (selection.StayingDateTo < stayFrom && selection.StayingDateTo < stayTill))
                            {
                                Console.WriteLine("Room Available!");
                                isDatesNotAvailable = true;
                                //get price of room
                                double price = 0;
                                foreach (RoomDetails room in listOfRoomDetails)
                                {
                                    if (room.RoomId == roomId)
                                    {
                                        //get the price per day of room
                                        price = room.PricePerDay;
                                        //break;
                                    }
                                }
                                //create room selection obj and add it to temp room selection list
                                RoomSelection selection1 = new RoomSelection(tempBook.BookingId, roomId, stayFrom, stayTill, price * noOfDaysOfBooking, noOfDaysOfBooking, BookingStatusus.Initiated);
                                tempListOfRoomSelection.Add(selection1);
                                //ask user if he wanna continue to book
                                Console.Write("Do u want to book another room? ");
                                userChoice = Console.ReadLine().ToLower();
                                if (userChoice == "yes")
                                {
                                    continue;
                                }
                                else
                                {
                                    //caluclate total rent amount
                                    double totalRentAmount = 0;
                                    foreach (RoomSelection tempSelection in tempListOfRoomSelection)
                                    {
                                        totalRentAmount += tempSelection.Price;
                                    }
                                    //modify booking obj details
                                    tempBook.TotalPrice = totalRentAmount;
                                    tempBook.BookingStatus = BookingStatusus.Booked;
                                    //check if user has enough balance
                                    if (currentUser.WalletBalance >= totalRentAmount)
                                    {
                                        //add Local selection obj to global selection obj
                                        foreach (RoomSelection tempSelection in tempListOfRoomSelection)
                                        {
                                            tempSelection.BookingStatus = BookingStatusus.Booked;
                                            listOfRoomSelection.Add(tempSelection);
                                        }
                                        //add local booking obj to global booking list
                                        listOfBookingDetails.Add(tempBook);
                                        //print booking id
                                        Console.WriteLine("Booking successfull! Booking id is " + tempBook.BookingId);
                                        currentUser.DeductBalance(totalRentAmount);
                                        break;
                                    }
                                    else
                                    {
                                        //ask user if he want to proceed booking after recharge
                                        Console.WriteLine("Insufficient balance, your booking price is Rs." + totalRentAmount);
                                        ShowWalletBalance();
                                        Console.Write("Do wanna book after recharging your wallet: ");
                                        string isWannaRecharge = Console.ReadLine().ToLower();
                                        if (isWannaRecharge == "yes")
                                        {
                                            double diff = totalRentAmount - currentUser.WalletBalance;
                                            Console.WriteLine("Please recharge more than or equal to Rs." + diff);

                                            RechargeWallet();
                                            if (currentUser.WalletBalance < totalRentAmount)
                                            {
                                                Console.WriteLine("still your wallet balance is insufficient!");
                                                break;
                                            }
                                            else
                                            {
                                                //add Local selection obj to global selection obj
                                                foreach (RoomSelection tempSelection in tempListOfRoomSelection)
                                                {
                                                    tempSelection.BookingStatus = BookingStatusus.Booked;
                                                    listOfRoomSelection.Add(tempSelection);
                                                }
                                                //add local booking obj to global booking list
                                                listOfBookingDetails.Add(tempBook);
                                                //print booking id
                                                Console.WriteLine("Booking successfull! Booking id is " + tempBook.BookingId);
                                                currentUser.DeductBalance(totalRentAmount);
                                                break;
                                            }
                                        }
                                        else
                                        {
                                            Console.WriteLine("Booking Not placed successfully");
                                            break;
                                        }

                                    }
                                }
                                /*//calculate total price
                                double price=0;
                                foreach(RoomDetails room in listOfRoomDetails){
                                    if(room.RoomId==roomId){
                                        //get the price per day of room
                                        price=room.PricePerDay;
                                        break;
                                    }
                                }
                                double totalPrice=price*noOfDaysOfBooking;
                                //check if user has enough balance
                                if(totalPrice<=currentUser.WalletBalance){

                                }
                            }
                            else{
                                Console.WriteLine("Room Unavailable!");
                                break;
                            }*/
                            }
                            else
                            {
                                Console.WriteLine("Room not available on entered Dates!");
                                break;
                            }
                        }
                        //if no room id matches with selection's room id , then that means room is available
                    }
                    if (!isDatesNotAvailable)
                    {
                        break;
                    }
                }
                else
                {
                    //if invalid room id then say
                    Console.WriteLine("Invalid Room id!");
                    break;
                }
            } while (userChoice != "no");
        }

        public static void CancelBooking()
        {
            Console.WriteLine("---------------------BOOKING HISTORY-------------------");
            //traverse through booking details list to match user id
            bool isBookingMade = false;
            foreach (BookingDetails booking in listOfBookingDetails)
            {
                if (currentUser.UserId == booking.UserId && booking.BookingStatus == BookingStatusus.Booked)
                {
                    isBookingMade = true;
                    Console.WriteLine("Booking ID: " + booking.BookingId);
                    Console.WriteLine("Total Price: Rs." + booking.TotalPrice);
                    Console.WriteLine("Date Booked: " + booking.DateOfBooking.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Booking Status: " + booking.BookingStatus);
                    Console.WriteLine("----------------------------------------------------");
                }
            }
            //at the end of the loop , if no booking found then say
            if (!isBookingMade)
            {
                Console.WriteLine("You haven't made any bookings yet!. To Book, please visit Option 'b'- Book Room ");
                Console.WriteLine();
            }
            //ask user booking id to cancel
            Console.Write("enter booking ID to cancel : ");
            string bookingId = Console.ReadLine();
            bool isValidBookingId = false;
            foreach (BookingDetails booking in listOfBookingDetails)
            {
                if (currentUser.UserId == booking.UserId && booking.BookingStatus == BookingStatusus.Booked && bookingId == booking.BookingId)
                {
                    isValidBookingId = true;
                    currentUser.WalletRecharge(booking.TotalPrice);
                    booking.BookingStatus = BookingStatusus.Cancelled;
                    //change booking status is selection list as well
                    Console.WriteLine("Booking cancelled successfully! Money returned to your wallet!");
                    foreach (RoomSelection room in listOfRoomSelection)
                    {
                        if (booking.BookingId == room.BookingId)
                        {
                            room.BookingStatus = BookingStatusus.Cancelled;
                        }
                    }
                }
            }
            //at the end of the loop , if no booking found then say
            if (!isValidBookingId)
            {
                Console.WriteLine("Invalid Booking ID!");
                Console.WriteLine();
            }

        }

        public static void ModifyBooking()
        {
            Console.WriteLine("---------------------BOOKING HISTORY-------------------");
            //traverse through booking details list to match user id
            bool isBookingMade = false;
            foreach (BookingDetails booking in listOfBookingDetails)
            {
                if (currentUser.UserId == booking.UserId && booking.BookingStatus == BookingStatusus.Booked)
                {
                    isBookingMade = true;
                    Console.WriteLine("Booking ID: " + booking.BookingId);
                    Console.WriteLine("Total Price: Rs." + booking.TotalPrice);
                    Console.WriteLine("Date Booked: " + booking.DateOfBooking.ToString("dd/MM/yyyy"));
                    Console.WriteLine("Booking Status: " + booking.BookingStatus);
                    Console.WriteLine("----------------------------------------------------");
                }
            }
            //at the end of the loop , if no booking found then say
            if (!isBookingMade)
            {
                Console.WriteLine("You haven't made any bookings yet!. To Book, please visit Option 'b'- Book Room ");
                Console.WriteLine();
            }
            //ask user booking id to cancel
            Console.Write("enter booking ID to modify : ");
            string bookingId = Console.ReadLine();
            bool isValidBookingId = false;
            foreach (BookingDetails booking in listOfBookingDetails)
            {
                if (currentUser.UserId == booking.UserId && booking.BookingStatus == BookingStatusus.Booked && bookingId == booking.BookingId)
                {
                    bool isValidSelectionId = false;
                    foreach (RoomSelection room in listOfRoomSelection)
                    {
                        if (booking.BookingId == room.BookingId)
                        {
                            Console.WriteLine("Selection ID: " + room.SelectionId);
                            Console.WriteLine("Booking ID: " + room.BookingId);
                            Console.WriteLine("Room ID: " + room.RoomId);
                            Console.WriteLine("Date staying from: " + room.StayingDateFrom.ToString("dd/MM/yyyy hh:mm tt"));
                            Console.WriteLine("Date staying till: " + room.StayingDateTo.ToString("dd/MM/yyyy hh:mm tt"));
                            Console.WriteLine("Price: " + room.NumberOfDays);
                            Console.WriteLine("Price: " + room.BookingStatus);
                            Console.WriteLine("------------------------------------------");
                        }
                    }
                    Console.Write("Enter the selection ID: ");
                    string selectionId = Console.ReadLine();
                    foreach (RoomSelection room in listOfRoomSelection)
                    {
                        if (room.SelectionId == selectionId && booking.UserId == currentUser.UserId)
                        {
                            isValidSelectionId = true;
                            Console.WriteLine("1.	Cancel selected room\n2.	Add new room");
                            Console.Write("Enter your choice: ");
                            int modifyChoice = int.Parse(Console.ReadLine());
                            switch (modifyChoice)
                            {
                                case 1:
                                    {
                                        CancelSelectedRoom(room, booking);
                                        break;
                                    }
                                case 2:
                                    {
                                        AddNewRoom(booking);
                                        break;
                                    }
                                default:
                                    {
                                        Console.WriteLine("Invalid Choice!");
                                        break;
                                    }
                            }
                        }
                    }
                    if (!isValidSelectionId)
                    {
                        Console.WriteLine("Invalid selection ID!");
                    }
                }
            }
            //at the end of the loop , if no booking found then say
            if (!isValidBookingId)
            {
                Console.WriteLine("Invalid Booking ID!");
                Console.WriteLine();
            }
        }
        public static void CancelSelectedRoom(RoomSelection room, BookingDetails booking)
        {
            currentUser.WalletRecharge(room.Price);
            room.BookingStatus = BookingStatusus.Cancelled;
            booking.TotalPrice -= room.Price;
            Console.WriteLine("Selected room cancelled from your booking");
        }

        public static void AddNewRoom(BookingDetails booking)
        {
            DisplayRooms();
            //ask user to enter room id , book date from and book date to and no od days of booking
            Console.Write("Enter the Room ID you wanna book: ");
            string roomId = Console.ReadLine();
            Console.Write("Enter the Date and time you wanna stay from (dd/MM/yyyy hh:mm tt): ");
            DateTime stayFrom = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy hh:mm tt", null);
            Console.Write("Enter the Date and time you wanna stay till (dd/MM/yyyy hh:mm tt): ");
            DateTime stayTill = DateTime.ParseExact(Console.ReadLine(), "dd/MM/yyyy hh:mm tt", null);
            Console.Write("Days required: ");
            int noOfDays = int.Parse(Console.ReadLine());
            int isValidRoomId = int.Parse(roomId.Remove(0, 3));
            if (isValidRoomId >= 101 && isValidRoomId <= 113)
            {
                bool isDatesNotAvailable = false;
                //traverse room selection list to check if it is booked using above details
                foreach (RoomSelection selection in listOfRoomSelection)
                {
                    if (selection.RoomId == roomId)
                    {
                        //condition for room available , either we are staying before their arrival or staying only after their arrival and has sufficient balance in acc
                        if ((selection.StayingDateFrom > stayFrom && selection.StayingDateFrom > stayTill) || (selection.StayingDateTo < stayFrom && selection.StayingDateTo < stayTill))
                        {
                            Console.WriteLine("Room Available!");
                            isDatesNotAvailable = true;
                            //get price of room
                            double price = 0;
                            foreach (RoomDetails room in listOfRoomDetails)
                            {
                                if (room.RoomId == roomId)
                                {
                                    //get the price per day of room
                                    price = room.PricePerDay*noOfDays;
                                    if(currentUser.WalletBalance>=price){
                                        currentUser.DeductBalance(price);
                                        booking.TotalPrice+=price;
                                        RoomSelection room1=new RoomSelection(booking.BookingId,roomId,stayFrom,stayTill,price,noOfDays,BookingStatusus.Booked);
                                        listOfRoomSelection.Add(room1);
                                        Console.Write("Booking modified successfully! ");


                                    }
                                    else{
                                        Console.WriteLine("The price of booking is Rs."+price+" but u have only "+currentUser.WalletBalance);
                                        Console.WriteLine("please recharge and book!");
                                        break;

                                    }
                                    
                                }
                            }
                        }
                        if(!isDatesNotAvailable){
                            Console.WriteLine("Dates not availalbe!");
                        }

                    }
                }
            }
            else{
                Console.WriteLine("Invalid room ID");
            }
        }
    }
}