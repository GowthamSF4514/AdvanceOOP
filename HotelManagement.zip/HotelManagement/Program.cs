﻿// See https://aka.ms/new-console-template for more information
using System;
using static HotelManagement.Operations;
namespace HotelManagement;
class Program{
    public static void Main(string[] args)
    {
        DefaultDatas();
        Mainmenu();
    }
}
